NES SFX Pack
2020 Programancer
Twitter: @Programancer
------------------------------------
$1 Non-Commercial License
$10 Commercial License

If you've purchased the Non-Commercial and you'd like to release your game commercially, please contact me on Twitter to arrange payment to upgrade your license.
------------------------------------
Notes:

This pack contains 42 sfx wav files for use in your NES style game. Names on the files are suggestions for use, and some are intended to have multiple uses. Each sound effect was made in Famitracker for the sake of authenticity.

Here is the list of sfx:

-MenuOpen.wav
-MenuOpen2.wav
-MenuClose.wav
-MenuClose2.wav
-MenuUp.wav
-MenuDown.wav
-MenuConfirm.wav
-Switch.wav
-Slash.wav
-Toss.wav
-SmallExplosion.wav
-Hit.wav
-Hit2.wav
-Hit3.wav
-Hit4.wav
-Hit5.wav
-Hit6.wav
-Hit7.wav
-Burn.wav
-ExplosionLoop.wav
-Explosion2.wav
-Splash.wav
-Throw.wav
-Pickup.wav
-Pickup2.wav
-MonsterShriek.wav
-Ouch1.wav
-Ouch2.wav
-Ouch3.wav
-Ouch4.wav
-Ouch5.wav
-LongExplosion.wav
-Charge.wav
-DoorOpen.wav
-DoorSlam.wav
-WaterSplash.wav
-FireMusket.wav
-Poot.wav
-Zap.wav
-LongZap.wav
-Fwoosh.wav
